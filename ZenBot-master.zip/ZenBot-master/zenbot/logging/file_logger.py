from .logger import Logger


class FileLogger(Logger):
    def __init__(self):
        pass
