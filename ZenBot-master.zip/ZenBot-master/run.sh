echo "Installing Poetry dependencies"
poetry update

echo "Running bot..."
poetry run start