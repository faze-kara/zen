## ZenBot

*WORK IS STILL IN PROGRESS. STATUS: WORKING PARTLY*

This is the official repo for the ZenBot. Feel free to fork it, and work on it.
The bot token can be changed in the `Config.py` file.
Upcoming website [zenbot.xyz](http://zenbot.xyz/)
For now you can use [this website](https://dmunch04.github.io/ZenBot/)

<br>

## Bugs

See any bugs, mistakes or just something that can be improved? Feel free to contact me on Discord: `Munchii#0117`, on mail: `contact@munchii.me` or create an issue! Thanks ;)

<br>

## Contributing
We would love some help on the ZenBot project! Make a pull request, and look in the TODO.txt, to see if you can help with anything

<br>

## Contributors
- **Munchii** - Initial Work & Founder : [Website](https://munchii.me)
- **A1phyte** - Contributor : [GitHub](https://github.com/A1phyte)
- **Assassinumz** - Contributor : [GitHub](https://github.com/Assassinumz)
